<link href="<?php echo base_url('resources/css/alejo.css'); ?>" rel="stylesheet">
<div class="box-header">
                <h3 class="box-title">Horarios Gestion II/2019</h3>
           
</div>
<div class="box-body table-responsive">
<table class="table table-striped" id="mitabla">
<tr>
<th>Hora</th>
<th >Lunes</th>
<th >Martes</th>
<th >Miercoles </th>
<th >Jueves</th>
<th >Viernes</th>
<th >Sabado</th>
</tr>
<tr>
<th>08:00 - 09:30</th>
<td>FISICA I (FIS100)<br>GRUPO 1<br>AULA 507</td>
<td>CALCULO I (CAL100)<br>GRUPO 1<br>AULA 507</td>
<td>CALCULO II (CAL200)<br>GRUPO 3<br>AULA 402</td> 
<td>CALCULO NUMERICO(CAL400)<br>GRUPO 3<br>AULA 510</td> 
<td>CALCULO NUMERICO(CAL400)<br>GRUPO 3<br>AULA 402</td>  
<td>ALGEBRA II (ALG200)<br>GRUPO 1<br>AULA 510</td> 
</tr>
<tr>
<th>09:30 - 11:00</th>
<td>CALCULO I (CAL100)<br>GRUPO 1<br>AULA 520</td>
<td>CALCULO II (CAL200)<br>GRUPO 3<br>AULA 507</td>
<td>CALCULO NUMERICO(CAL400)<br>GRUPO 3<br>AULA 402</td> 
<td>CIRCUITOS I (CIR100)<br>GRUPO 1<br>AULA 402</td> 
<td></td> 
<td></td> 
</tr>
<tr>
<th>11:00 - 12:30</th>
<td>ALGEBRA II (ALG200)<br>GRUPO 1<br>AULA 507</td>
<td>ALGEBRA II (ALG200)<br>GRUPO 1<br>AULA 402</td>
<td></td> 
<td></td> 
<td>FISICA I (FIS100)<br>GRUPO 1<br>AULA 402</td>
<td></td> 
</tr>
<tr>
<th>12:30 - 14:00</th>
<td></td>
<td></td>
<td>CALCULO I (CAL100)<br>GRUPO 1<br>AULA 510</td>
<td></td> 
<td>CIRCUITOS I (CIR100)<br>GRUPO 1<br>AULA 510</td> 
<td></td> 
</tr>
<tr>
<th>14:00 - 15:30</th>
<td></td>
<td></td>
<td></td> 
<td>FISICA I (FIS100)<br>GRUPO 1<br>AULA 507</td>
<td></td> 
<td></td> 
</tr>
<tr>
<th>15:30 - 17:00</th>
<td>CIRCUITOS I (CIR100)<br>GRUPO 1<br>AULA 507</td>
<td></td>
<td></td> 
<td></td> 
<td>CALCULO II (CAL200)<br>GRUPO 3<br>AULA 507</td> 
<td></td> 
</tr>
<tr>
<th>17:00 - 18:30</th>
<td>CALCULO II (CAL200)<br>GRUPO 4<br>AULA 402</td>
<td>CALCULO II (CAL200)<br>GRUPO 4<br>AULA 430</td>
<td>CALCULO II (CAL200)<br>GRUPO 4<br>AULA 430</td> 
<td></td> 
<td></td> 
<td></td> 
</tr>
<tr>
<th>18:30 - 20:00</th>
<td>ALGEBRA II (ALG200)<br>GRUPO 1<br>AULA 430</td>
<td></td>
<td>ALGEBRA II (ALG200)<br>GRUPO 1<br>AULA 430</td> 
<td></td> 
<td>ALGEBRA II (ALG200)<br>GRUPO 1<br>AULA 510</td>
<td></td> 
</tr>
</table>
</div>