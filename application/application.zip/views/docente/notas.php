<link href="<?php echo base_url('resources/css/alejo.css'); ?>" rel="stylesheet">
<div class="box-header">
                <h3 class="box-title">Notas/Calificaciones</h3>
           
            </div>
<div class="box-body table-responsive">
                <table class="table table-striped" id="mitabla">
                    <tr>
                    	<th>Grupo</th>
                        <th>Materia</th>
                        <th>Estudiantes</th>
                        <th>Gestion</th>
                        <th></th>
                    </tr>
          			<tr>
          				<td>GRUPO 1</td>
          				<td>FISICA I (FIS100)</td>
          				<td align="right">21</td>
          				<td align="center">II-2019</td>
                              <td align="center"><a href="nota/1" class="btn btn-warning btn-xs">Notas</a></td>
          			</tr>
          			<tr>
          				<td>GRUPO 1</td>
          				<td>CALCULO I (CAL100)</td>
          				<td align="right">18</td>
          				<td align="center">II-2019</td>
                              <td align="center"><a href="nota/1" class="btn btn-warning btn-xs">Notas</a></td>
          			</tr>

          			<tr>
          				<td>GRUPO 3</td>
          				<td>CALCULO II (CAL200)</td>
          				<td align="right">26</td>
          				<td align="center">II-2019</td>
                              <td align="center"><a href="nota/1" class="btn btn-warning btn-xs">Notas</a></td>
          			</tr>
          			<tr>
          				<td>GRUPO 4</td>
          				<td>CALCULO II (CAL200)</td>
          				<td align="right">18</td>
          				<td align="center">II-2019</td>
                              <td align="center"><a href="nota/1" class="btn btn-warning btn-xs">Notas</a></td>
          			</tr>
          			<tr>
          				<td>GRUPO 1</td>
          				<td>ALGEBRA II (ALG200)</td>
          				<td align="right">19</td>
          				<td align="center">II-2019</td>
                              <td align="center"><a href="nota/1" class="btn btn-warning btn-xs">Notas</a></td>
          			</tr>
          			<tr>
          				<td>GRUPO 3</td>
          				<td>ALGEBRA II (ALG200)</td>
          				<td align="right">23</td>
          				<td align="center">II-2019</td>
                              <td align="center"><a href="nota/1" class="btn btn-warning btn-xs">Notas</a></td>
          			</tr>
          			<tr>
          				<td>GRUPO 3</td>
          				<td>CALCULO NUMERICO(CAL400)</td>
          				<td align="right">21</td>
          				<td align="center">II-2019</td>
                              <td align="center"><a href="nota/1" class="btn btn-warning btn-xs">Notas</a></td>
          			</tr>
          			<tr>
          				<td>GRUPO 1</td>
          				<td>CIRCUITOS I (CIR100)</td>
          				<td align="right">23</td>
          				<td align="center">II-2019</td>
                              <td align="center"><a href="nota/1" class="btn btn-warning btn-xs">Notas</a></td>
          			</tr>
          		</table>
</div>