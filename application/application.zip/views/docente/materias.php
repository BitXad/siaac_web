<link href="<?php echo base_url('resources/css/alejo.css'); ?>" rel="stylesheet">
<div class="box-header">
                <h3 class="box-title">Materias</h3>
           
            </div>
<div class="box-body table-responsive">
                <table class="table table-striped" id="mitabla">
                    <tr>
                        <th>Materia</th>
                        <th>Codigo</th>
                        <th>Nivel</th>
                        <th>Area</th>
                        <th>Gestion</th>
                    </tr>
          			<tr>
          				<td>FISICA I </td>
                  <td align="center">(FIS100)</td>
          				<td>NIVEL 1</td>
                  <td>TECNOLOGIA</td>
          				<td align="center">II-2019</td>
          			</tr>
                <tr>
                  <td>CALCULO I </td>
                  <td align="center">(CAL100)</td>
                  <td>NIVEL 1</td>
                  <td>TECNOLOGIA</td>
                  <td align="center">II-2019</td>
                </tr>
                <tr>
                  <td>CALCULO II </td>
                  <td align="center">(CAL200)</td>
                  <td>NIVEL 2</td>
                  <td>TECNOLOGIA</td>
                  <td align="center">II-2019</td>
                </tr>
                <tr>
                  <td>ALGEBRA II </td>
                  <td align="center">(ALG200)</td>
                  <td>NIVEL 2</td>
                  <td>TECNOLOGIA</td>
                  <td align="center">II-2019</td>
                </tr>
                <tr>
                  <td>CALCULO NUMERICO </td>
                  <td align="center">(CAL400)</td>
                  <td>NIVEL 4</td>
                  <td>TECNOLOGIA</td>
                  <td align="center">II-2019</td>
                </tr>
                <tr>
                  <td>CIRCUITOS I </td>
                  <td align="center">(CIR100)</td>
                  <td>NIVEL 1</td>
                  <td>TECNOLOGIA</td>
                  <td align="center">II-2019</td>
                </tr>
          			
          		</table>
</div>