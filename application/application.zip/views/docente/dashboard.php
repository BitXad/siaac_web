<section class="content">
      <!-- Info boxes -->
      <div class="row">
   <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
              <div class="inner" >
                
                
                <?php 
                    
                    //$interlineado = "<script> document.write(interlineado);</script>";
                    $interlineado = "";
                    
                ?>    

                <?php echo $interlineado; ?>

                
              <h4><b>GRUPOS</b></h4>
              <p>8</p>
              
            </div>
              
            <div class="icon">
              <i class="fa fa-group"></i>              
            </div>
            <a href="<?php echo base_url('docente/grupos'); ?>" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-purple">
              <div class="inner" >
                
                
                <?php 
                    
                    //$interlineado = "<script> document.write(interlineado);</script>";
                    $interlineado = "";
                    
                ?>    

                <?php echo $interlineado; ?>
                
              <h4><b>MATERIAS</b></h4>
              <p>6</p>
              
            </div>
              
            <div class="icon">
              <i class="fa fa-database"></i>              
            </div>
            <a href="<?php echo base_url('docente/materias'); ?>" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
              <div class="inner" >
                
                
                <?php 
                    
                    //$interlineado = "<script> document.write(interlineado);</script>";
                    $interlineado = "";
                    
                ?>    

                <?php echo $interlineado; ?>
                
              <h4><b>HORARIOS</b></h4>
              <p>-</p>
              
            </div>
              
            <div class="icon">
              <i class="fa fa-clock-o"></i>              
            </div>
            <a href="<?php echo base_url('docente/horarios'); ?>" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
              <div class="inner" >
                
                
                <?php 
                    
                    //$interlineado = "<script> document.write(interlineado);</script>";
                    $interlineado = "";
                    
                ?>    

                <?php echo $interlineado; ?>
                
              <h4><b>NOTAS</b></h4>
              <p>-</p>
              
            </div>
              
            <div class="icon">
              <i class="fa fa-clipboard"></i>              
            </div>
            <a href="<?php echo base_url('docente/notas'); ?>" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
 
</section>