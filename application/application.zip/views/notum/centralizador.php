<!------------------ ESTILO DE LAS TABLAS ----------------->
<link href="<?php echo base_url('resources/css/tabla_centralizador.css'); ?>" rel="stylesheet">
<link href="<?php echo base_url('resources/css/cabecera.css'); ?>" rel="stylesheet">
<!-------------------------------------------------------->
<div style="padding-top: -50px"><center class="escala">
<table class="table table-striped" id="tutabla" style="width: 31.5cm;margin-bottom: 0;">
              		
                            <tr>
                                   <td colspan="2" style="padding-bottom: 0"><img src="<?php echo base_url('resources/images/ministerio.png'); ?>" width="180" height="70"></td>
                                   <td colspan="10"></td>
                                   <td colspan="3" align="center" style="font-size: 10pt">Codigo de Registro: 03-ELC </td>
                            </tr>
                          
                            <tr>
                                   <td  colspan="2" align="center">COCHABAMBA-BOLIVIA</td>
                                   <td></td>
                                  
                                   <td colspan="10" rowspan="2" align="center" style="vertical-align:middle;font-size: 22pt;font-family: Arial Narrow,Arial,sans-serif; "><b>CENTRALIZADOR DE CALIFICACIONES</b></td>
                                
                                   <td align="center" style="font-size: 10pt;border-left: 3px solid black !important;border-top: 3px solid black !important">N° LIBRO</td>
                                   <td style="font-size: 10pt;border-right: 3px solid black !important;border-top: 3px solid black !important">3</td>
                            </tr>
                            <tr>
                                   <td colspan="13"></td>                                   
                                   <td align="center" style="font-size: 10pt;border-left: 3px solid black !important;border-bottom: 3px solid black !important">N° FOLIO</td>
                                   
                                   <td style="font-size: 10pt;border-right: 3px solid black !important;border-bottom: 3px solid black !important">123</td>
                            </tr>
                            <tr>
                                   <td colspan="13"></td>
                                   <td colspan="2" style="font-size: 10pt"><b>TURNO:</b> Tarde</td>
                            </tr>
                            <tr>
                                   <td colspan="10" style="font-size: 10pt;"><b>INSTITUCIÓN:</b>  INSTITUTO TECNOLÓGICO INDUSTRIAL COMERCIAL "PUERTO DE MEJILLONES"</td>
                                   <td style="font-size: 10pt"><b>R.M.</b></td>
                                   <td style="font-size: 10pt">2505/2018</td>
                                   <td></td>
                                   <td colspan="2" style="font-size: 10pt"><b>CARÁCTER:</b> FISCAL</td>
                            </tr>
                            
                            <tr>
                                   <td style="width: 0.7cm;"></td>
                                   <td style="width: 4.5cm;"></td>
                                   <td style="width: 3.8cm;"></td>
                                   <td style="width: 2cm;"></td>
                                   <td style="width: 1cm;"></td>
                                   <td style="width: 1.95cm;"></td>
                                   <td style="width: 1.95cm;"></td>
                                   <td style="width: 1.95cm;"></td>
                                   <td style="width: 1.95cm;"></td>
                                   <td style="width: 1.95cm;"></td>
                                   <td style="width: 1.95cm;"></td>
                                   <td style="width: 1.95cm;"></td>
                                   <td style="width: 1.95cm;"></td>
                                   <td style="width: 2.5cm;"></td>
                                   <td style="width: 1.4cm;"></td>
                                  
                                   
                            </tr>
</table>
<table class="table table-striped" id="mitabla" style="width: 31.5cm;margin-top: 0">
              		<tr>
              			<td colspan="3" style="font-size: 12pt" ><b>GESTIÓN:</b> I/2018</td>
              			<td rowspan="6" colspan="2" align="center" style="height: 4.8cm;vertical-align:middle;padding-bottom: 0;padding-top: 0" ><p class="textvertical" style="font-size: 11pt"><b>CÉDULA DE IDENTIDAD</b></p></td>
              			<td style="font-size: 10t" align="center" style="padding-left: 0px;padding-right: 0px">MAT-100</td>
                                   <td style="font-size: 10pt" align="center" style="padding-left: 0px;padding-right: 0px">SIS-100</td>
                                   <td style="font-size: 10pt" align="center" style="padding-left: 0px;padding-right: 0px">FIS-100</td>
                                   <td style="font-size: 10pt" align="center" style="padding-left: 0px;padding-right: 0px">QUI-100</td>
                                   <td style="font-size: 10pt" align="center" style="padding-left: 0px;padding-right: 0px">CIR-100</td>
                                   <td style="font-size: 10pt" align="center" style="padding-left: 0px;padding-right: 0px">SIM-100</td>
                                   <td style="font-size: 10pt" align="center" style="padding-left: 0px;padding-right: 0px"></td>
                                   <td style="font-size: 10pt" align="center" style="padding-left: 0px;padding-right: 0px"></td>
                                   <td rowspan="6" colspan="2" align="center" style="height: 4.6cm;vertical-align:middle;" ><p class="textvertical" style="font-size: 11pt"><b>OBSERVACIONES</b></p></td>
              		</tr>
              		<tr>
              			<td colspan="3" style="font-size: 12pt"><b>NIVEL:</b>  TÉCNICO SUPERIOR</td>
              			<td rowspan="5" style="vertical-align:bottom;" align="center"><p class="textvertical">MATEMATICA </p></td>
                                   <td rowspan="5" style="vertical-align:bottom;" align="center"><p class="textvertical">ANALISIS CIRCUITOS</p></td>
                                   <td rowspan="5" style="vertical-align:bottom;" align="center"><p class="textvertical">FISICA </p></td>
                                   <td rowspan="5" style="vertical-align:bottom;" align="center"><p class="textvertical">QUIIMICA</p></td>
                                   <td rowspan="5" style="vertical-align:bottom;" align="center"><p class="textvertical">CIRCUITOS</p></td>
                                   <td rowspan="5" style="vertical-align:bottom;" align="center"><p class="textvertical">SEGURIDAD INDUSTRIAL</p></td>
                                   <td rowspan="5" style="vertical-align:bottom;" align="center"><p class="textvertical"></p></td>
                                   <td rowspan="5" style="vertical-align:bottom;" align="center"><p class="textvertical"></p></td>
              		</tr>
              		<tr>
              			<td colspan="3" style="font-size: 12pt"><b>CARRERA:</b> ELECTRÓNICA</td>
              			
              		</tr>
              		<tr>
              			<td colspan="3" style="font-size: 12pt"><b>RÉGIMEN:</b> SEMESTRAL</td>
              			
              		</tr>
              		<tr>
              			<td colspan="3" style="font-size: 12pt"><b>CURSO:</b> PRIMERO</td>
              			
              		</tr>
                            <tr>
                                   <td style="width: 0.7cm;font-size: 11pt" ><b>N°</b></td>
                                   <td colspan="2" style="width: 7cm;font-size: 11pt" align="center"><b>NÓMINA ESTUDIANTES</b></td>
                                   
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">1</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;">SALGUERO CAMACHO</td>
                                   <td style="width: 3.8cm;border-left: hidden !important;">WILDER</td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;">8891942</td>
                                   <td style="width: 1cm;border-left: hidden !important;">SC</td>
                                   <td align="center" style="width: 1.95cm;">-</td>
                                   <td align="center" style="width: 1.95cm;">-</td>
                                   <td align="center" style="width: 1.95cm;">-</td>
                                   <td align="center" style="width: 1.95cm;">-</td>
                                   <td align="center" style="width: 1.95cm;">-</td>
                                   <td align="center" style="width: 1.95cm;">-</td>
                                   <td align="center" style="width: 1.95cm;">-</td>
                                   <td align="center" style="width: 1.95cm;">-</td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important">Abandono</td>   
                            </tr>
                                   <td align="center" style="width: 0.7cm;">2</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;">HEREDIA VASQUEZ</td>
                                   <td style="width: 3.8cm;border-left: hidden !important;">JUAN ALEJANDRO</td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;">7959931</td>
                                   <td style="width: 1cm;border-left: hidden !important;">CB</td>
                                   <td align="center">80</td>
                                   <td align="center">90</td>
                                   <td align="center">51</td>
                                   <td align="center">64</td>
                                   <td align="center">82</td>
                                   <td align="center">38</td>
                                   <td align="center">-</td>
                                   <td align="center">-</td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important">Reprobado</td>   
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">3</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">4</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">5</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr> 
                            <tr>
                                   <td align="center" style="width: 0.7cm;">6</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">7</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">8</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">9</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr> 
                            <tr>
                                   <td align="center" style="width: 0.7cm;">10</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">11</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">12</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">13</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">14</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">15</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">16</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                            <tr>
                                   <td align="center" style="width: 0.7cm;">17</td>
                                   <td style="width: 4.5cm;border-right: hidden !important;"></td>
                                   <td style="width: 3.8cm;border-left: hidden !important;"></td>
                                   <td align="right" style="width: 2cm;border-right: hidden !important;"></td>
                                   <td style="width: 1cm;border-left: hidden !important;"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center"></td>
                                   <td align="center" style="font-size: 11pt;border-right: 3px solid black !important"></td> 
                            </tr>
                          
                      
              	</table>
                     
                     <table class="table table-striped" id="tutabla" style="width: 31.5cm;margin-bottom: 0;">
                            <tr>
                                   <td align="center"><em>Prof. Felix Martín Aruquipa Apaza</em><br><b>JEFE DE CARRERA</b></td>
                                   <td align="center"><em>Lic. Juan Bautista Soto Peñaranda</em><br><b>DIRECTOR ACADEMICO</b></td>
                                   <td align="center"><em>Arq. Iván Gregorio Quiroga Gonzáles</em><br><b>RECTOR</b></td>
                                   <td align="center"><b>SELLO INSTITUTO</b></td>
                            </tr>
                     </table>
                     </center>
                     </div>